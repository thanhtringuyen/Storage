
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "cpu.h"
#include "memory.h"
#include "pipeline.h"

#define REG_COUNT 16
 
CPU* CPU_init()
{
    CPU* cpu = malloc(sizeof(*cpu));
    if (!cpu) {
        return NULL;
    }

    /* Create register files */
    cpu->regs= create_registers(REG_COUNT);

    return cpu;
}

/*
 * This function de-allocates CPU cpu.
 */
void CPU_stop(CPU* cpu)
{
    free(cpu);
}

void print_line(FILE* f) {
    fprintf(f, "================================\n");
}

/*
 * This function prints the content of the registers.
 */
void print_registers(FILE* f, CPU *cpu) {
    
    // fprintf(f, "================================\n");
    fprintf(f, "--------------------------------\n");
    for (int reg=0; reg<REG_COUNT; reg++) {
        fprintf(f, "REG[%2d]   |   Value=%d  \n", reg, cpu->regs[reg].value);
        fprintf(f, "--------------------------------\n");
    }
    fprintf(f, "================================\n");
}

bool update_pipeline(CPU* cpu, Pipeline pipelines[], int pipelines_cnt, Memory* memory) {
    int new_pipelines_cnt = 1;
    bool completed = true;
    bool not_incremented = false;
    int in_use[REG_COUNT][2];

    for (int i=0; i<REG_COUNT; ++i) 
        in_use[i][0] = 0, in_use[i][1] = -1;

    for (int index = 0; index < pipelines_cnt; ++index) {
        if (not_incremented)
            return false;
        if (is_new(&pipelines[index])) {
            if (new_pipelines_cnt == 0)
                return false;
            else
                --new_pipelines_cnt;
        }

        if (pipelines[index].stage->index == 3) {
            if (!is_return(&pipelines[index])) {
                if (is_op(&pipelines[index], "st")) {
                    if (pipelines[index].dest->is_register && in_use[pipelines[index].dest->loc][0]) {
                        not_incremented = true;
                        goto after_increment;
                    }
                } else {
                    for (int i=0; (i<2-is_op_set_or_ld(&pipelines[index])); ++i) {
                        if (pipelines[index].src[i]->is_register && in_use[pipelines[index].src[i]->loc][0]) {
                            int used_pipeline_idx = in_use[pipelines[index].src[i]->loc][1];
                            if (pipelines[used_pipeline_idx].stage->index > 7) {
                                not_incremented = true;
                                goto after_increment;
                            }
                            if (pipelines[used_pipeline_idx].stage->index == 7 && is_op(&pipelines[used_pipeline_idx], "div")) {
                                continue;
                            }
                            if (pipelines[used_pipeline_idx].stage->index == 6 && is_op(&pipelines[used_pipeline_idx], "mul")) {
                                continue;
                            }
                            if (pipelines[used_pipeline_idx].stage->index == 5 && is_op(&pipelines[used_pipeline_idx], "add")) {
                                continue;
                            }
                            if (pipelines[used_pipeline_idx].stage->index == 5 && is_op(&pipelines[used_pipeline_idx], "set")) {
                                continue;
                            }
                            if (pipelines[used_pipeline_idx].stage->index == 5 && is_op(&pipelines[used_pipeline_idx], "sub")) {
                                continue;
                            }
                            not_incremented = true;
                            goto after_increment;
                        }
                    }
                }
            }
        }

        increment_stage(pipelines[index].stage);

        after_increment:

        if (pipelines[index].stage->index > 4 && pipelines[index].stage->index <= 11 && (!is_return(&pipelines[index]))) {    
            if (!is_op(&pipelines[index], "st")) {
                if (pipelines[index].dest->is_register) {
                    in_use[pipelines[index].dest->loc][0] = 1;
                    in_use[pipelines[index].dest->loc][1] = index;
                }
            }
        }
        
        if (pipelines[index].stage->index <= 10)
            completed = false;
        if (pipelines[index].stage->index != 10)
            goto after_computation;
        
        if (is_op_set_or_ld(&pipelines[index])) {
            int l = pipelines[index].src[0]->is_register ? cpu->regs[pipelines[index].src[0]->loc].value : pipelines[index].src[0]->loc;
            if (is_op(&pipelines[index], "ld"))
                cpu->regs[pipelines[index].dest->loc].value = memory_get(memory, l);
            else if (is_op(&pipelines[index], "set"))
                cpu->regs[pipelines[index].dest->loc].value = l;
            else {
                int mem_idx = (pipelines[index].src[0]->is_register ? cpu->regs[pipelines[index].src[0]->loc].value : pipelines[index].src[0]->loc);
                memory_put(memory, mem_idx, cpu->regs[pipelines[index].dest->loc].value);
            }
        } else if (!is_return(&pipelines[index])) {
            int l = pipelines[index].src[0]->is_register ? cpu->regs[pipelines[index].src[0]->loc].value : pipelines[index].src[0]->loc;
            int r = pipelines[index].src[1]->is_register ? cpu->regs[pipelines[index].src[1]->loc].value : pipelines[index].src[1]->loc;

            if (is_op(&pipelines[index], "add"))
                cpu->regs[pipelines[index].dest->loc].value = l + r;
            else if (is_op(&pipelines[index], "sub")) 
                cpu->regs[pipelines[index].dest->loc].value = l - r;
            else if (is_op(&pipelines[index], "mul")) 
                cpu->regs[pipelines[index].dest->loc].value = l * r;
            else if (is_op(&pipelines[index], "div")) 
                cpu->regs[pipelines[index].dest->loc].value = l / r;  
        }

        after_computation:
        ;
    }
    return completed;
}

void print_cur_cycle(FILE* f, Pipeline pipelines[], int pipelines_cnt, int cycle) {
    fprintf(f, "================================\n");
    fprintf(f, "Clock Cycle #: %d\n", cycle);
    fprintf(f, "--------------------------------\n");
    for (int index = 0; index < pipelines_cnt; ++index) {
        if (is_new(&pipelines[index]))
            break;
        if (pipelines[index].stage->index > 10)
            continue;
        print_pipeline(&pipelines[index], f);
    }
}

void print_result(FILE* f, CPU* cpu, Pipeline pipelines[], int pipelines_cnt, int cycle) {

    fprintf(f, "================================\n");
    fprintf(f, "Clock Cycle #: %d\n", cycle);
    fprintf(f, "--------------------------------\n");
    for (int reg = 0; reg < REG_COUNT; reg++) {
        fprintf(f, "REG[ %d] | Value=%d\n", reg, cpu->regs[reg].value);
        fprintf(f, "--------------------------------\n");
    }
    fprintf(f, "================================\n\n");
}

void print_stats(FILE* f, int cycles, int pipelines) {
    fprintf(f, "Stalled cycles due to data hazard: %d\n",  cycles - (pipelines + 10));
    fprintf(f, "Total execution cycles: %d\n", cycles);
    fprintf(f, "Total instruction simulated:%d\n", pipelines);
    fprintf(f, "IPC: %f\n", (pipelines * 1.0) / cycles);
}

void print_file_to_console(FILE *f) {
    char ch = fgetc(f);
    while (ch != EOF) {
        printf("%c", ch);
        ch = fgetc(f);
    }
}

void print_memory(FILE* f, Memory* m) {
    for (int i=0; i<MEM_MAP_SZ; ++i) {
        fprintf(f, "%d ", m->map[i]);
    }
}

/*
 *  CPU CPU simulation loop
 */
int CPU_run(CPU* cpu, Pipeline pipelines[], int pipelines_cnt, Memory* memory) {
    FILE* pipeline_file = fopen("pipeline.txt", "w");
    FILE* result_file = fopen("result.txt", "w");
    FILE* output_memory_file = fopen("output_memory.txt", "w");

    int cycles = 1;
    while (true) {
        bool completed = update_pipeline(cpu, pipelines, pipelines_cnt, memory);
        if (completed)
            break;
        print_result(result_file, cpu, pipelines, pipelines_cnt, cycles);
        print_cur_cycle(pipeline_file, pipelines, pipelines_cnt, cycles);
        cycles++;
    }
    --cycles;
    print_line(pipeline_file);
    fprintf(pipeline_file, "\n");
    print_line(result_file);
    fprintf(result_file, "\n");
    fprintf(result_file, "=============== STATE OF ARCHITECTURAL REGISTER FILE ==========\n\n");
    print_registers(result_file, cpu);
    fprintf(result_file, "\n");
    print_stats(result_file, cycles, pipelines_cnt);
    print_memory(output_memory_file, memory);
    fclose(pipeline_file);
    fclose(result_file);

    result_file = fopen("result.txt", "r");
    

    print_file_to_console(result_file);
    
    fclose(result_file);
    return 0;
}

Register* create_registers(int size){
    Register* regs = malloc(sizeof(*regs) * size);
    if (!regs) {
        return NULL;
    }
    for (int i=0; i<size; i++){
        regs[i].value = 0;
        // regs[i].in_use = false;
    }
    return regs;
}

