#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "memory.h"

int memory_get(Memory* m, int idx) {
    return m->map[idx/4];
}

void memory_put(Memory* m, int loc, int val) {
    m->map[loc/4] = val;
}

Memory* read_memory_from_file(char* filename) {
    FILE* f = fopen(filename, "r");
    Memory* m = (Memory*)malloc(sizeof(Memory));
    int index = 0, value = 0;

    fscanf(f, "%d", &value);
    while (!feof(f)) {
        m->map[index] = value;
        index++;
        fscanf(f, "%d", &value);
    }
    fclose(f);
   /*printf("Read memory_map from file\n");*/
    return m;
}
