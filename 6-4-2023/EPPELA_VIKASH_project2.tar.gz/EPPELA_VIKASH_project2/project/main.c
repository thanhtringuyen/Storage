//
//  main.c
//  Pipeline
//
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cpu.h"
#include "pipeline.h"
#include "memory.h"

#define MAX_PIPELINES 200

int binary_flag;


void run_cpu_fun(Pipeline pipelines[], int pipelines_cnt, Memory* memory) {
    CPU *cpu = CPU_init();
    CPU_run(cpu, pipelines, pipelines_cnt, memory);
    CPU_stop(cpu);
    free(memory);
}

int main(int argc, const char * argv[]) {
    setbuf(stdout, NULL);
    if (argc<=1) {
        fprintf(stderr, "Error : missing required args\n");
        return -1;
    }

    char* filename = (char*)argv[1];
    char* mem_filename = "memory_map.txt";

    Pipeline pipelines[MAX_PIPELINES];
    int pipelines_cnt = build_pipeline_array(pipelines, filename);
    Memory* memory = read_memory_from_file(mem_filename);

    run_cpu_fun(pipelines, pipelines_cnt, memory);
    return 0;
}
