#ifndef _PIPELINE_H_
#define _PIPELINE_H_
#include <stdbool.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Stage {
    char* stage;
    int index;
} Stage;

typedef struct Storage {
    int loc;
    bool is_register;
} Storage;

typedef struct Pipeline {
    char* op;
    char* mem_loc;
    Stage* stage;
    Storage* src[2];
    Storage* dest;
} Pipeline;

char* get_stage_name_by_index(int idx);

Stage* new_stage(int index);

void increment_stage(Stage* stage);

Storage* new_storage(char* str);

char* get(Storage* storage);

void print(Storage* storage, FILE* f);

bool is_return(Pipeline* pipeline);

bool is_op_set_or_ld(Pipeline* pipeline);

bool is_op(Pipeline* pipeline, char* op);

bool is_new(Pipeline* pipeline);

bool is_mem2_stage(Pipeline* pipeline);

void print_pipeline(Pipeline* pipeline, FILE* f);

int build_pipeline_array(Pipeline pipelines[], char* filename);

#endif
