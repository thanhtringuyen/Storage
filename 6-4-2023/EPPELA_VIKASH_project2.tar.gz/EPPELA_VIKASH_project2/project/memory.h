#ifndef _MEM_H_
#define _MEM_H_

#include <stdbool.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MEM_MAP_SZ 16384

typedef struct Memory {
    int map[MEM_MAP_SZ];
} Memory;

int memory_get(Memory* m, int loc);


void memory_put(Memory* m, int loc, int val);

Memory* read_memory_from_file(char* filename);

#endif
