#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "pipeline.h"

#define PIPELINE_LINE_SZ 100
#define PIPELINE_MEM_LOC_SZ 10
#define PIPELINE_OP_SZ 10


char* get_stage_name_by_index(int idx) {
    switch (idx) {
        case 0:
            return "IF";
        case 1:
            return "ID";
        case 2:
            return "IA";
        case 3:
            return "RR";
        case 4:
            return "ADD";
        case 5:
            return "MUL";
        case 6:
            return "DIV";
        case 7:
            return "BR";
        case 8:
            return "Mem1";
        case 9:
            return "Mem2";  
        case 10 :
            return "WB";    
        default:
            return "NIL";
    }
}

Stage* new_stage(int index) {
    Stage* stage = (Stage*)(malloc(sizeof(Stage)));
    stage->index = index;
    stage->stage = get_stage_name_by_index(index);
    return stage;
}

void increment_stage(Stage* stage) {
    if (stage->index > 11)
        return;
    stage->index++;
    stage->stage=get_stage_name_by_index(stage->index);
}

Storage* new_storage(char* str) {
    Storage* storage = (Storage*)malloc(sizeof(Storage));
    storage->is_register = (str[0] == 'R');
    storage->loc = atoi(str+1);
    return storage;
}

char* get(Storage* storage) {
    char* result = (char*) malloc(sizeof(char) * 5);
    if (storage->is_register) {
        sprintf(result, "R%d", storage->loc);
    } else {
        sprintf(result, "#%d", storage->loc);
    }
    return result;
}

void print(Storage* storage, FILE* f) {
    char* result = get(storage);
    fprintf(f, "%s ", get(storage));
    free(result);
}

bool is_return(Pipeline* pipeline) {
    return (strcmp(pipeline->op, "ret") == 0);
}

bool is_op_set_or_ld(Pipeline* pipeline) {
    return (strcmp(pipeline->op, "set") == 0 || strcmp(pipeline->op, "st") == 0 || strcmp(pipeline->op, "ld") == 0);
}

bool is_op(Pipeline* pipeline, char* ch) {
    bool status = (strcmp(pipeline->op, ch) == 0);
    return status;
}

bool is_new(Pipeline* pipeline) {
    return (pipeline->stage->index == -1);
}

bool is_mem2_stage(Pipeline* pipeline) {
    return (is_op(pipeline, "ld") && (pipeline->stage->index == 9));
}

void newline(FILE* f) {
    fprintf(f, "\n");
}

void print_pipeline(Pipeline* pipeline, FILE* f) {
    fprintf(f, "%s\t: %s %s ", pipeline->stage->stage, pipeline->mem_loc, pipeline->op);
    if (is_return(pipeline)) {
        newline(f);
        return;
    }
    print(pipeline->dest, f);
    print(pipeline->src[0], f);
    if (is_op_set_or_ld(pipeline)) {
        newline(f);
        return;
    }
    print(pipeline->src[1], f);
    newline(f);
    return;
}

int build_pipeline_array(Pipeline pipelines[], char* filename) {
    FILE* f = fopen(filename, "r");
    char* str = malloc(PIPELINE_LINE_SZ * sizeof(char));
    int cur_index = 0;

    while (!feof(f)) {
        if (fgets(str, PIPELINE_LINE_SZ, f) == NULL)
            break;
        if (str[strlen(str)-1] == '\n') {
            str[strlen(str)-1] = '\0';
        }
        pipelines[cur_index].mem_loc = malloc(PIPELINE_MEM_LOC_SZ * sizeof(char));
        pipelines[cur_index].op = malloc(PIPELINE_OP_SZ * sizeof(char));
        pipelines[cur_index].stage = new_stage(-1);

        char* cur_string = strtok(str, " ");
        strcpy(pipelines[cur_index].mem_loc, cur_string);
        cur_string = strtok(NULL, " ");
        strcpy(pipelines[cur_index].op, cur_string);
        if (is_return(&pipelines[cur_index])) {
            cur_index++;
            continue;
        }
        cur_string = strtok(NULL, " ");
        pipelines[cur_index].dest = new_storage(cur_string);
        int num_srcs = is_op_set_or_ld(&pipelines[cur_index]) ? 1 : 2;
        for (int src_index=0; src_index<num_srcs; src_index++) {
            cur_string = strtok(NULL, " ");
            pipelines[cur_index].src[src_index] = new_storage(cur_string);
        }
        cur_index += 1;
    }
   /*printf("Read %d pipelines from %s\n", cur_index, filename);*/
    return cur_index;
}

