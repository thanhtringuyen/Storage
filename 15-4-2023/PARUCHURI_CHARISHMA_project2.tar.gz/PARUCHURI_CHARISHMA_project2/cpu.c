#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "cpu.h"

#define REG_COUNT 16
#define MAX_LINE_LENGTH 200
#define MAX_LINE 16384
int flag_red = 0;
Instruction register_read(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i);
int multiplier(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i);
int adder(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i);
int divider(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i);

int *store_memory_map()
{
    static int memory_map[MAX_LINE];
    int n = 0;
    FILE *fp = fopen("memory_map.txt", "r");
    while ((n < MAX_LINE) && (!feof(fp)))
    {
        fscanf(fp, "%d\n", &memory_map[n]);
        n++;
    }
    fclose(fp);
    return memory_map;
}

void writeback(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i, Memory_map *mem)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            if (instruct.opcode == 6)
            {
                int location = cpu->regs[instruct.dest].value / 4;
                mem->memory_map[location] = instruct_arr[i].output;
            }
            else
            {
                cpu->regs[instruct.dest].value = instruct_arr[i].output;
            }
        }
        else
        {
            int location = instruct.dest / 4;
            mem->memory_map[location] = cpu->regs[instruct.op1].value;
        }
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 0;
        }
        // printf("WB--------->%s,out %d\n", instruct.line, instruct.output);
    }
}

Instruction memory2(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i, Memory_map *mem)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (i - 1 >= 0 && instruct.opreg1 == instruct_arr[i - 1].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3 || instruct.opcode == 4))
        {
            instruct.op1 = instruct_arr[i - 1].output;
            instruct_arr[i].op1 = instruct.op1;
            if (instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3)
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
            else if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            // else{
            // instruct.output = divider(instruct_arr, instruct_arr[i], cpu, i);
            // }
        }
        if (i - 1 >= 0 && instruct.opreg2 == instruct_arr[i - 1].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3 || instruct.opcode == 4))
        {
            instruct.op2 = instruct_arr[i - 1].output;
            instruct_arr[i].op2 = instruct.op2;
            if (instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3)
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
            else if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            // else{
            // instruct.output = divider(instruct_arr, instruct_arr[i], cpu, i);
            // }
        }

        if (instruct.opcode == 5)
        {
            if (instruct.reg_op1 == 1)
            {
                int location = instruct.op1 / 4;
                instruct.output = mem->memory_map[location];
                cpu->regs[instruct.dest].temp_value = instruct.output;
            }
            else
            {
                int location = instruct.op1 / 4;
                instruct.output = mem->memory_map[location];
                cpu->regs[instruct.dest].temp_value = instruct.output;
            }
        }
        if (instruct.opcode == 6)
        {
            if (instruct.reg_op1 == 1)
            {
                instruct.output = instruct.op1;
                cpu->regs[instruct.dest].temp_value = instruct.output;
            }
            else
            {
                int location = instruct.op1 / 4;
                instruct.output = mem->memory_map[location];
            }
        }
        // printf("M2--------->%s\n", instruct.line);
    }
    instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].reg_op2 = instruct.reg_op2;
    instruct_arr[i].reg_dest = instruct.reg_dest;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].structFlag = instruct.structFlag;
    instruct_arr[i].output = instruct.output;
    return instruct;
}

Instruction memory1(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (i - 2 >= 0 && instruct.opreg1 == instruct_arr[i - 2].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op1 = instruct_arr[i - 2].output;
            instruct_arr[i].op1 = instruct.op1;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (i - 2 >= 0 && instruct.opreg2 == instruct_arr[i - 2].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op2 = instruct_arr[i - 2].output;
            instruct_arr[i].op2 = instruct.op2;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        // printf("M1--------->%s\n", instruct.line);
    }
    return instruct;
}

Instruction branch(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (i - 3 >= 0 && instruct.opreg1 == instruct_arr[i - 3].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op1 = instruct_arr[i - 3].output;
            instruct_arr[i].op1 = instruct.op1;

            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (i - 3 >= 0 && instruct.opreg2 == instruct_arr[i - 3].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op2 = instruct_arr[i - 3].output;
            instruct_arr[i].op2 = instruct.op2;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        instruct_arr[i].output = instruct.output;
        // printf("BR--------->%s\n", instruct.line);
    }
    return instruct;
}

int divider(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (i - 1 >= 0 && instruct.opreg1 == instruct_arr[i - 1].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {

            instruct.op1 = instruct_arr[i - 1].output;
            instruct_arr[i].op1 = instruct.op1;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (i - 1 >= 0 && instruct.opreg2 == instruct_arr[i - 1].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op2 = instruct_arr[i - 1].output;
            instruct_arr[i].op2 = instruct.op2;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (i - 4 >= 0 && instruct.opreg1 == instruct_arr[i - 4].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op1 = instruct_arr[i - 4].output;
            instruct_arr[i].op1 = instruct.op1;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (i - 4 >= 0 && instruct.opreg2 == instruct_arr[i - 4].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2 || instruct.opcode == 3))
        {
            instruct.op2 = instruct_arr[i - 4].output;
            instruct_arr[i].op2 = instruct.op2;
            if (instruct.opcode == 3)
            {
                instruct.output = multiplier(instruct_arr, instruct_arr[i], cpu, i);
            }
            else
            {
                instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
            }
        }
        if (instruct.opcode == 4)
        {
            if (instruct.op2 == 0)
            {
                instruct.output = 0;
            }
            else
            {
                instruct.output = instruct.op1 / instruct.op2;
            }
            cpu->regs[instruct.dest].temp_value = instruct.output;
        }
        // printf("DIV--------->%s\n", instruct.line);
    }
    instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].reg_op2 = instruct.reg_op2;
    instruct_arr[i].reg_dest = instruct.reg_dest;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].output = instruct.output;
    return instruct.output;
}

int multiplier(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (i - 1 >= 0 && instruct.opreg1 == instruct_arr[i - 1].dest && instruct.reg_op1 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2))
        {
            instruct.op1 = instruct_arr[i - 1].output;
            instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
        }
        if (i - 1 >= 0 && instruct.opreg2 == instruct_arr[i - 1].dest && instruct.reg_op2 != 0 && (instruct.opcode == 0 || instruct.opcode == 1 || instruct.opcode == 2))
        {
            instruct.op2 = instruct_arr[i - 1].output;
            instruct.output = adder(instruct_arr, instruct_arr[i], cpu, i);
        }
        if (instruct.opcode == 3)
        {
            instruct.output = instruct.op1 * instruct.op2;
            cpu->regs[instruct.dest].temp_value = instruct.output;
        }
        // printf("MUL--------->%s\n", instruct.line);
    }
    instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].reg_op2 = instruct.reg_op2;
    instruct_arr[i].reg_dest = instruct.reg_dest;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].output = instruct.output;
    return instruct.output;
}

int adder(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (instruct.opcode == 0)
        {

            instruct.output = instruct.op1;
            cpu->regs[instruct.dest].temp_value = instruct.output;
            instruct_arr[i].output = instruct.output;
        }
        if (i != 5 && (instruct.opcode == 1 || instruct.opcode == 2) && instruct.opreg1 == instruct_arr[i - 1].dest)
        {
            instruct.op1 = instruct_arr[i - 1].output;
        }
        if (i != 5 && (instruct.opcode == 1 || instruct.opcode == 2) && instruct.opreg2 == instruct_arr[i - 1].dest)
        {
            instruct.op2 = instruct_arr[i - 1].output;
        }
        if (i != 6 && (instruct.opcode == 1 || instruct.opcode == 2) && instruct.opreg2 == instruct_arr[i - 2].dest)
        {
            instruct.op2 = instruct_arr[i - 2].output;
        }
        if (i != 6 && instruct.reg_op1 == 1 && (instruct.opcode == 1 || instruct.opcode == 2) && instruct.opreg1 == instruct_arr[i - 2].dest)
        {
            instruct.op1 = instruct_arr[i - 2].output;
        }
        if (instruct.opcode == 1)
        {
            instruct.output = instruct.op1 + instruct.op2;
            cpu->regs[instruct.dest].temp_value = instruct.output;
            instruct_arr[i].output = instruct.output;
        }
        if (instruct.opcode == 2)
        {
            instruct.output = instruct.op1 - instruct.op2;
            cpu->regs[instruct.dest].temp_value = instruct.output;
            instruct_arr[i].output = instruct.output;
        }
    }
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].output = instruct.output;
    return instruct.output;
}

Instruction register_read(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        if (instruct.reg_op1 == 1)
        {
            instruct.opreg1 = instruct.op1;
            if (cpu->regs[instruct.opreg1].is_writing == 1 && instruct.opreg1 != instruct.dest)
            {
                instruct.op1 = cpu->regs[instruct.opreg1].temp_value;
            }
            else
            {
                instruct.op1 = cpu->regs[instruct.opreg1].value;
            }
        }
        if (instruct.reg_op2 == 1)
        {
            instruct.opreg2 = instruct.op2;
            if (cpu->regs[instruct.opreg2].is_writing == 1 && instruct.opreg2 != instruct.dest)
            {
                instruct.op2 = cpu->regs[instruct.opreg2].temp_value;
            }
            else
            {
                instruct.op2 = cpu->regs[instruct.opreg2].value;
            }
        }
        // printf("RR--------->%s,%d,%d\n", instruct.line, instruct.op1, instruct.op2);
        instruct_arr[i].op1 = instruct.op1;
        instruct_arr[i].opreg1 = instruct.opreg1;
        instruct_arr[i].opreg2 = instruct.opreg2;
        instruct_arr[i].op2 = instruct.op2;
    }
    return instruct;
}

Instruction analyse(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_dest == 1)
        {
            cpu->regs[instruct.dest].is_writing = 1;
        }
        // printf("IA--------->%s\n", instruct.line);
    }
    return instruct;
}

int decode_register(char *addr)
{
    char *res = addr + 1;
    return atoi(res);
}

Instruction decode(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        char opc[10][10];
        int j = 0, ctr = 0;
        for (int i = 0; i <= (strlen(instruct.line)); i++)
        {
            if (instruct.line[i] == ' ' || instruct.line[i] == '\0')
            {
                opc[ctr][j] = '\0';
                ctr++;
                j = 0;
            }
            else
            {
                opc[ctr][j] = instruct.line[i];
                j++;
            }
        }
        instruct.opcode_str = opc[1];
        instruct.dest = decode_register(opc[2]);
        if (opc[2][0] == 'R')
        {
            instruct.reg_dest = 1;
        }
        else
        {
            instruct.reg_dest = 0;
        }
        if (opc[3][0] == 'R')
        {
            instruct.reg_op1 = 1;
        }
        else
        {
            instruct.reg_op1 = 0;
        }
        if (opc[4][0] == 'R')
        {
            instruct.reg_op2 = 1;
        }
        else
        {
            instruct.reg_op2 = 0;
        }
        instruct.op1 = decode_register(opc[3]);

        instruct.op2 = decode_register(opc[4]);
        if (strcmp(opc[1], "set") == 0)
        {
            instruct.opcode = 0;
        }
        else if (strcmp(opc[1], "add") == 0)
        {
            instruct.opcode = 1;
        }
        else if (strcmp(opc[1], "sub") == 0)
        {
            instruct.opcode = 2;
        }
        else if (strcmp(opc[1], "mul") == 0)
        {
            instruct.opcode = 3;
        }
        else if (strcmp(opc[1], "div") == 0)
        {
            instruct.opcode = 4;
        }
        else if (strcmp(opc[1], "ld") == 0)
        {
            instruct.opcode = 5;
        }
        else if (strcmp(opc[1], "st") == 0)
        {
            instruct.opcode = 6;
            instruct.dest = decode_register(opc[3]);
            instruct.op1 = decode_register(opc[2]);
            if (opc[3][0] != 'R')
            {
                instruct.reg_dest = 0;
            }
            if (opc[2][0] != 'R')
            {
                instruct.reg_op1 = 0;
            }
        }
        if (opc[1] != NULL)
        {
            // printf("ID--------->%s\n", instruct.line);
        }
        instruct_arr[i].line = instruct.line;
        instruct_arr[i].opcode_str = instruct.opcode_str;
        instruct_arr[i].opcode = instruct.opcode;
        instruct_arr[i].dest = instruct.dest;
        instruct_arr[i].op1 = instruct.op1;
        instruct_arr[i].reg_op1 = instruct.reg_op1;
        instruct_arr[i].reg_op2 = instruct.reg_op2;
        instruct_arr[i].reg_dest = instruct.reg_dest;
        instruct_arr[i].op2 = instruct.op2;
        instruct_arr[i].flag = instruct.flag;
        instruct_arr[i].opreg1 = -1;
        instruct_arr[i].opreg2 = -1;
        instruct_arr[i].structFlag = 0;
        instruct_arr[i].output = instruct.output;
    }
}

Instruction fetch(char *line, struct Instruction *instruct, const char *filename, CPU *cpu, int i)
{
    instruct[i].line = line;
    // printf("IF--------->%s\n", instruct[i].line);
}

void print_registers(CPU *cpu)
{

    printf("================================\n");
    printf("--------------------------------\n");
    // int reg =7;
    for (int reg = 0; reg < REG_COUNT; reg++)
    {
        printf("REG[%2d] | Value=%d \n", reg, cpu->regs[reg].value);
        printf("--------------------------------\n");
    }
    printf("================================\n\n");
}

void pipeline(const char *filename, CPU *cpu)
{
    struct Instruction *instructs_arr = (Instruction *)malloc(1000 * sizeof(Instruction));
    char lines_arr[1000][100];
    int cyl = 0;
    FILE *fp = fopen(filename, "r");
    while (fgets(lines_arr[cyl], MAX_LINE_LENGTH, fp) != 0)
    {
        cyl++;
    }
    int instructs = cyl;
    cyl = cyl + 10;
    int i = 0, hazards = 0;
    int *p;
    p = store_memory_map();
    Memory_map *mem = (Memory_map *)malloc(sizeof(Memory_map));
    mem->memory_map = p;
    while (i < cyl)
    {

        printf("\nClock: %d\n", i + 1);
        if (i - 10 >= 0)
        {
            writeback(instructs_arr, instructs_arr[i - 10], cpu, i - 10, mem);
        }
        if (i - 9 >= 0)
        {
            memory2(instructs_arr, instructs_arr[i - 9], cpu, i - 9, mem);
        }
        if (i - 8 >= 0)
        {
            memory1(instructs_arr, instructs_arr[i - 8], cpu, i - 8);
        }
        if (i - 7 >= 0)
        {
            branch(instructs_arr, instructs_arr[i - 7], cpu, i - 7);
        }
        if (i - 6 >= 0)
        {
            divider(instructs_arr, instructs_arr[i - 6], cpu, i - 6);
        }
        if (i - 5 >= 0)
        {
            multiplier(instructs_arr, instructs_arr[i - 5], cpu, i - 5);
        }
        if (i - 4 >= 0)
        {
            adder(instructs_arr, instructs_arr[i - 4], cpu, i - 4);
        }
        if (i - 3 >= 0)
        {
            register_read(instructs_arr, instructs_arr[i - 3], cpu, i - 3);
        }
        if (i - 2 >= 0)
        {
            analyse(instructs_arr, instructs_arr[i - 2], cpu, i - 2);
        }
        if (i - 1 >= 0)
        {
            decode(instructs_arr, instructs_arr[i - 1], cpu, i - 1);
        }
        fetch(lines_arr[i], instructs_arr, filename, cpu, i);

        print_registers(cpu);
        i = i + 1;
        cpu->cyl = cyl;
        cpu->instructs = instructs;
    }
    FILE *outputFile;
    outputFile = fopen("output_memory.txt", "w+");
    mem->memory_map[0] = 0;
    for (int i = 0; i < MAX_LINE; i++)
    {
        fprintf(outputFile, "%d ", mem->memory_map[i]);
    }
    fclose(outputFile);
    fclose(fp);
    free(instructs_arr);
}

CPU *CPU_init(const char *filename, const char *memory_file)
{
    if (!filename)
    {
        return NULL;
    }
    CPU *cpu = malloc(sizeof(*cpu));
    if (!cpu)
    {
        return NULL;
    }
    /* Create register files */
    cpu->regs = create_registers(REG_COUNT);
    pipeline(filename, cpu);

    return cpu;
}

/*
 * This function de-allocates CPU cpu.
 */
void CPU_stop(CPU *cpu)
{
    // free(cpu->instructs);
    free(cpu);
}

/*
 * CPU CPU simulation loop
 */
int CPU_run(CPU *cpu)
{
    printf("=============== STATE OF ARCHITECTURAL REGISTER FILE ==========");
    print_registers(cpu);
    int inst = cpu->instructs;
    int cy = cpu->cyl;
    float ipc = (float)inst / (float)cy;

    printf("Stalled cycles due to data hazard: \n");
    printf("Total execution cycles: %d\n", cpu->cyl);
    printf("Total instruction simulated:%d\n", cpu->instructs);
    printf("IPC: %.6f\n", ipc);

    return 0;
}

Register *
create_registers(int size)
{
    Register *regs = malloc(sizeof(*regs) * size);
    if (!regs)
    {
        return NULL;
    }
    for (int i = 0; i < size; i++)
    {
        regs[i].value = 0;
        regs[i].is_writing = 0;
    }
    return regs;
}