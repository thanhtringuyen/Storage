#ifndef _CPU_H_
#define _CPU_H_
#include <stdbool.h>
#include <assert.h>
// #define MAX_LINE 16500
// extern int memory_map[MAX_LINE][1];
typedef struct Instruction
{
    char* line;
    char* opcode_str;
    int opcode;
    int dest;
    int op1;
	int reg_op1;
    int op2;
	int flag;
	// int stage;
    int structFlag;
	int output;
} Instruction;

typedef struct Register
{
    int value;          // contains register value
    int is_writing;    // indicate that the register is current being written
                        // True: register is not ready
                        // False: register is ready
} Register;

typedef struct Memory_map
{
    int* memory_map;
} Memory_map;


/* Model of CPU */
typedef struct CPU
{
    /* Integer register file */
    Register *regs;  
    int data;
    int cyl;
    int instructs;
    int struct_hazards;  
} CPU;

CPU*
CPU_init();

Register*
create_registers(int size);

int
CPU_run(CPU* cpu);

void
CPU_stop(CPU* cpu);

#endif