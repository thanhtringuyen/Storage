#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "cpu.h"

#define REG_COUNT 128
#define MAX_LINE_LENGTH 100
#define MAX_LINE 16500

int fetch_flag=1;

int *store_memory_map()
{
    static int memory_map[MAX_LINE];
    int n = 0;
    FILE *fp = fopen("memory_map.txt", "r");
    while ((n < MAX_LINE) && (!feof(fp)))
    {
        fscanf(fp, "%d\n", &memory_map[n]);
        ++n;
    }
    return memory_map;
}

void writeback(Instruction *instruct_arr,struct Instruction instruct, CPU *cpu,int i)
{
    if (instruct.line != NULL)
    {
        // cpu->regs[0].value=0;
        cpu->regs[instruct.dest].value = instruct_arr[i].output;
        cpu->regs[instruct.dest].is_writing=0;
        // printf("wb output %d", instruct_arr[i].output);
        printf("WB--------->%s", instruct.line);
    }
}

Instruction memory2(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.opcode == 5)
        {
            fetch_flag=0;
            if (instruct.reg_op1 == 1)
            {
                instruct.output = instruct.op1;
            }
            else
            {
                int *p;
                p = store_memory_map();
                Memory_map *mem = (Memory_map *)malloc(sizeof(Memory_map));
                mem->memory_map = p;
                int location = instruct.op1 / 4;
                printf("memory map %d", mem->memory_map[location]);
                instruct.output = mem->memory_map[location];
            }
        }
        printf("M2--------->%s\n", instruct.line);
    }
    instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].structFlag = instruct.structFlag;
    instruct_arr[i].output = instruct.output;
    return instruct;
}

Instruction memory1(struct Instruction instruct, CPU *cpu)
{
    if (instruct.line != NULL)
    {
        if (instruct.opcode == 5)
        {
            instruct.structFlag = 1;
        }
        printf("M1--------->%s\n", instruct.line);
    }
    return instruct;
}

Instruction branch(struct Instruction instruct, CPU *cpu)
{
    if (instruct.line != NULL)
    {
        printf("BR--------->%s\n", instruct.line);
    }
    return instruct;
}

Instruction divider(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        // multiplier(instruct, cpu);
        // printf("I am at divider\n");
        if (instruct.opcode == 4)
        {
            instruct.output = instruct.op1 / instruct.op2;
        }
        printf("DIV--------->%s\n", instruct.line);
    }
        instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].output = instruct.output;
    return instruct;
}

Instruction multiplier(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.opcode == 3)
        {
            instruct.output = instruct.op1 * instruct.op2;
        }
        printf("MUL--------->%s\n", instruct.line);
    }
        instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].output = instruct.output;
    return instruct;
}

Instruction adder(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    //  printf("add opcode",instruct.opcode);
    if (instruct.line != NULL)
    {
        // register_read(instruct, cpu);
        // printf("I am at adder\n");
        if (instruct.opcode == 0)
        {
            instruct.output = instruct.op1;
            instruct_arr[i].output = instruct.output;
        }
        else if (instruct.opcode == 1)
        {
            instruct.output = instruct.op1 + instruct.op2;
            instruct_arr[i].output = instruct.output;
        }
        else if (instruct.opcode == 2)
        {
            instruct.output = instruct.op1 - instruct.op2;
            instruct_arr[i].output = instruct.output;
        }

        printf("ADD--------->%s\n", instruct.line);
    }
    return instruct;
}

Instruction register_read(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        if (instruct.reg_op1 == 1)
        {
            instruct.op1=cpu->regs[instruct.op1].value;
        }
        printf("RR--------->%s\n", instruct.line);
        instruct_arr[i].op1 = instruct.op1;
    }
    return instruct;
}

Instruction analyse(struct Instruction instruct, CPU *cpu)
{
    if (instruct.line != NULL)
    {

        printf("IA--------->%s\n", instruct.line);
    }
    return instruct;
}

int decode_register(char *addr)
{
    char *res = addr + 1;
    return atoi(res);
}

Instruction decode(Instruction *instruct_arr, struct Instruction instruct, CPU *cpu, int i)
{
    if (instruct.line != NULL)
    {
        char opc[10][10];
        int j = 0, ctr = 0;
        for (int i = 0; i <= (strlen(instruct.line)); i++)
        {
            if (instruct.line[i] == ' ' || instruct.line[i] == '\0')
            {
                opc[ctr][j] = '\0';
                ctr++;
                j = 0; 
            }
            else
            {
                opc[ctr][j] = instruct.line[i];
                j++;
            }
        }
        instruct.opcode_str = opc[1];
        instruct.dest = decode_register(opc[2]);
        if (opc[3][0] == 'R')
        {
            instruct.reg_op1 = 1;
        }
        else
        {
            instruct.reg_op1 = 0; 
        }
        instruct.op1 = decode_register(opc[3]);
        
        instruct.op2 = decode_register(opc[4]);
        if (strcmp(opc[1], "set") == 0)
        {
            instruct.opcode = 0;
        }
        else if (strcmp(opc[1], "add") == 0)
        {
            instruct.opcode = 1;
        }
        else if (strcmp(opc[1], "sub") == 0)
        {
            instruct.opcode = 2;
        }
        else if (strcmp(opc[1], "mul") == 0)
        {
            instruct.opcode = 3;
        }
        else if (strcmp(opc[1], "div") == 0)
        {
            instruct.opcode = 4;
        }
        else if (strcmp(opc[1], "ld") == 0)
        {
            instruct.opcode = 5;
        }
        if (opc[1] != NULL)
        {
            printf("ID--------->%s\n", instruct.line);
        }
    }
    instruct_arr[i].line = instruct.line;
    instruct_arr[i].opcode_str = instruct.opcode_str;
    instruct_arr[i].opcode = instruct.opcode;
    instruct_arr[i].dest = instruct.dest;
    instruct_arr[i].op1 = instruct.op1;
    instruct_arr[i].reg_op1 = instruct.reg_op1;
    instruct_arr[i].op2 = instruct.op2;
    instruct_arr[i].flag = instruct.flag;
    instruct_arr[i].structFlag = 0;
    instruct_arr[i].output = instruct.output;
}

Instruction fetch(char *line, struct Instruction *instruct, const char *filename, CPU *cpu, int i)
{
    instruct[i].line = line;
    printf("IF--------->%s\n", instruct[i].line);
}

void pipeline(const char *filename, CPU *cpu)
{
    struct Instruction *instructs_arr = (Instruction *)malloc(1100 * sizeof(Instruction));
    char lines_arr[1000][100];
    int cyl = 0;
    FILE *fp = fopen(filename, "r");
    while(fgets(lines_arr[cyl], MAX_LINE_LENGTH, fp)!=0){
        cyl++;
    }
    int instructs=cyl;
    int struct_hazards=0;
    cyl=cyl+10;
    int i=0,h=0;
    while (i < cyl)
    {

        printf("\nClock: %d\n", i+1);
        writeback(instructs_arr,instructs_arr[i - 10], cpu,i-10);
        memory2(instructs_arr, instructs_arr[i - 9], cpu, i - 9);
        memory1(instructs_arr[i - 8], cpu);
        branch(instructs_arr[i - 7], cpu);
        divider(instructs_arr, instructs_arr[i - 6], cpu, i - 6);
        multiplier(instructs_arr, instructs_arr[i - 5], cpu, i - 5);
        adder(instructs_arr, instructs_arr[i - 4], cpu, i - 4);
        register_read(instructs_arr, instructs_arr[i - 3], cpu, i - 3);
        analyse(instructs_arr[i - 2], cpu);
        decode(instructs_arr, instructs_arr[i - 1], cpu, i - 1);
        if(!fetch_flag){
            fetch(NULL, instructs_arr, filename, cpu, i);
            fetch_flag=1;
            cyl=cyl+1;
            struct_hazards++;
        }
        else{
        fetch(lines_arr[h], instructs_arr, filename, cpu, i);
        h=h+1;
        }
        i = i + 1;
        cpu->cyl=cyl;
        cpu->struct_hazards=struct_hazards;
        cpu->instructs=instructs;
    }
}

CPU *CPU_init(const char *filename, const char *memory_file)
{
    if (!filename)
    {
        return NULL;
    }
    CPU *cpu = malloc(sizeof(*cpu));
    if (!cpu)
    {
        return NULL;
    }
    /* Create register files */
    cpu->regs = create_registers(REG_COUNT);
    pipeline(filename, cpu);

    return cpu;
}

/*
 * This function de-allocates CPU cpu.
 */
void CPU_stop(CPU *cpu)
{
    free(cpu);
}

/*
 * This function prints the content of the registers.
 */
void print_registers(CPU *cpu)
{

    printf("================================\n");
    printf("--------------------------------\n");
    for (int reg = 0; reg < REG_COUNT; reg++)
    {
        printf("REG[%2d]   |   Value=%d  \n", reg, cpu->regs[reg].value);
        printf("--------------------------------\n");
    }
    printf("================================\n\n");
}

/*
 *  CPU CPU simulation loop
 */
int CPU_run(CPU *cpu)
{
    // printf("HERE");
    print_registers(cpu);
    int inst = cpu->instructs;
    int cy = cpu->cyl;
    float ipc= (float)inst/(float)cy;

    printf("Stalled cycles due to structural hazard: %d\n",cpu->struct_hazards);
    printf("Total execution cycles: %d\n",cpu->cyl);
    printf("Total instruction simulated:%d\n",cpu->instructs);
    printf("IPC: %.6f\n",ipc);

    return 0;
}

Register *
create_registers(int size)
{
    Register *regs = malloc(sizeof(*regs) * size);
    if (!regs)
    {
        return NULL;
    }
    for (int i = 0; i < size; i++)
    {
        regs[i].value = 0;
    }
    return regs;
}