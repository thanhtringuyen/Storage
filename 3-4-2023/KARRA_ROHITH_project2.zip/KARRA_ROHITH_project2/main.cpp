#include <iostream>
#include <vector>
#include <fstream>
#include <map>
#include <iomanip>
using namespace std;

int NUM_INSTRUCTIONS = 0;
int BLOCKED_COUNT = 0;
const int REG_COUNT = 16;
vector<string> address;
vector<string> task;
vector<string> src1, src2;
vector<string> dest;
vector<int> stage;
vector<int> new_in_cycles(1000, 0);
vector<bool> instruction_blocked_in_cycle(1000, false);
vector<int> blocked(REG_COUNT, 0);
vector<bool> forwarded(REG_COUNT, false);
vector<int> memory(16384, 0);
vector<int> reg(REG_COUNT, 0);
map<int, string> stages_details;
map<string, int> forwarding;
ofstream mem_out;
ifstream mem_in;
ifstream pipeline_in;
int cycles = 0;
int blocked_cycles = 0;

bool is_register(string loc) {
    if (loc == "-1")
        return false;
    return (loc[0] == 'R');
}

int get_register_value(string loc) {
    return stoi(loc.substr(1));
}

int get_mem_value(string mem_loc) {
    return stoi(mem_loc.substr(1));
}


bool all_executed() {
    for (int i=0; i<NUM_INSTRUCTIONS; ++i) {
        if (stage[i] <= 10)
            return false;
    }
    return true;
}

int is_instruction_blocked(int idx) {
    if (task[idx] == "ret") {
        return -1;
    } else if (task[idx] == "st") {
        int val = get_register_value(dest[idx]);
        if (is_register(dest[idx]) && (forwarded[val] == false) && blocked[val] > 0) {
            return get_register_value(dest[idx]);
        } else {
            return -1;
        }
    } else {
        int val = get_register_value(src1[idx]);
        if (is_register(src1[idx]) && (forwarded[val] == false) && blocked[val] > 0) {
            return val;
        }
        val = get_register_value(src2[idx]);
        if (is_register(src2[idx]) && (forwarded[val] == false) && blocked[val] > 0) {
            return val;
        }
        return -1;
    }
}

void print_cycle(int cycle) {
    cout << "================================\n";
    cout << "Clock Cycle #: " << cycle << "\n";
    cout << "--------------------------------\n";

    cout << "================================\n";
    cout << "Clock Cycle #: " << cycle << "\n";
    cout << "--------------------------------\n";

    for (int i=0; i<NUM_INSTRUCTIONS; ++i) {
        if (stage[i] > 10 || stage[i] == -1)
            continue;
        cout << stages_details[stage[i]] << " : " << address[i] << " " << task[i];
        if (task[i] != "ret") {
            if (task[i] == "set" || task[i] == "ld" || task[i] == "st") {
                cout << " " << dest[i] << " " << src1[i];
            } else {
                cout << " " << dest[i] << " " << src1[i] << " " << src2[i];
            }
        }
        cout << "\n"; 
    }

    for (int i=0; i<REG_COUNT; ++i) {
        cout << "REG[ " << i << "]" << " | Value=" << reg[i] << "\n";
        cout << "--------------------------------\n";
    }
    cout << "================================\n\n";
}

void print_final_res() {
    --cycles;
    cout << "================================\n\n";
    cout << "=============== STATE OF ARCHITECTURAL REGISTER FILE ==========\n\n";
    cout << "--------------------------------\n";

    for (int i=0; i<REG_COUNT; ++i) {
        cout << "REG[ " << i << "]" << " | Value=" << reg[i] << "\n";
        cout << "--------------------------------\n";
    }
    cout << "================================\n\n";

    cout << "Stalled cycles due to data hazard: " << blocked_cycles << "\n";
    cout << "Total execution cycles: " << cycles << "\n";
    cout << "Total instruction simulated: " << NUM_INSTRUCTIONS << "\n";
    cout << "IPC: " << fixed << setprecision(6) << (NUM_INSTRUCTIONS * 1.0 / cycles) << "\n";

}

void run_single(int cycle, int idx) {
    if (instruction_blocked_in_cycle[cycle]) {
        return;
    }
    
    if (stage[idx] == -1) {
        if (new_in_cycles[cycle] == 0) {
            stage[idx]++;
            new_in_cycles[cycle]++;
        }
        return;
    }

    // RR stage
    if (stage[idx] == 3) {
        int reg_blocked = is_instruction_blocked(idx);
        if (reg_blocked == -1) {
            stage[idx]++;
        } else {
            instruction_blocked_in_cycle[cycle] = true;
            blocked_cycles++;
        }
        return;
    } else if (stage[idx] < 3 || stage[idx] >= 11) {
        stage[idx]++;
        return;
    } else {
        // stage > RR and stage <= WB
        if (task[idx] == "ret") {
            stage[idx]++;
            return;
        } 

        // exec operation if WB
        if (stage[idx] == 9) {
            if (task[idx] == "set" || task[idx] == "ld" || task[idx] == "st") {
                int src1_val = is_register(src1[idx]) ? reg[get_register_value(src1[idx])] : get_mem_value(src1[idx]);
                if (task[idx] == "set")
                    reg[get_register_value(dest[idx])] = src1_val;
                else if (task[idx] == "ld")
                    reg[get_register_value(dest[idx])] = memory[src1_val/4];
                else
                    memory[src1_val/4] = reg[get_register_value(dest[idx])];
            } else {
                int src1_val, src2_val, dest_val;
                dest_val = get_register_value(dest[idx]);
                src1_val = is_register(src1[idx]) ? reg[get_register_value(src1[idx])] : get_mem_value(src1[idx]);
                src2_val = is_register(src2[idx]) ? reg[get_register_value(src2[idx])] : get_mem_value(src2[idx]);
                if (task[idx] == "add")
                    reg[dest_val] = src1_val + src2_val;
                else if (task[idx] == "sub")
                    reg[dest_val] = src1_val - src2_val;
                else if (task[idx] == "mul")
                    reg[dest_val] = src1_val * src2_val;
                else if (task[idx] == "div")
                    reg[dest_val] = src1_val / src2_val;
            }
        }

        // block dest if not st
        if (task[idx] != "st") {
           if (is_register(dest[idx])) {
                blocked[get_register_value(dest[idx])]++;
                
            }
        }

        if (forwarding.find(task[idx]) != forwarding.end() && forwarding[task[idx]] == stage[idx]) {
            if (is_register(dest[idx])) {
                forwarded[get_register_value(dest[idx])] = true;
                
            }
        }
        stage[idx]++;
    }
    return;
}

void print_final_memory() {
    for (auto e: memory)
        mem_out << e << " ";
    
}

void run() {
    while (1) {
        cycles++;
        for (int i=0; i<REG_COUNT; ++i)
            forwarded[i] = false, blocked[i] = 0;
        for (int i=0; i<NUM_INSTRUCTIONS; ++i) {
            run_single(cycles, i);
        }

        if (all_executed())
            break;
        print_cycle(cycles);
    }
    cout << "================================\n\n";
    print_final_res();
    print_final_memory();
}


void init() {

    stages_details[0] = "IF";
    stages_details[1] = "ID";
    stages_details[2] = "IA";
    stages_details[3] = "RR";
    stages_details[4] = "ADD";
    stages_details[5] = "MUL";
    stages_details[6] = "DIV";
    stages_details[7] = "BR";
    stages_details[8] = "MEM1";
    stages_details[9] = "MEM2";
    stages_details[10] = "WB";

    forwarding["add"] = forwarding["set"] = forwarding["sub"] = 4;
    forwarding["mul"] = 5;
    forwarding["div"] = 6;

    mem_out.open("output_memory.txt");
}

int main(int argc, char* argv[]) {
    init();
    pipeline_in.open(argv[1]);
    mem_in.open("memory_map.txt");

    for (auto &e : memory)
        mem_in >> e;
    
    while (1) {
        string loc;
        string cur_addr;
        string cur_task;
        pipeline_in >> cur_addr >> cur_task;
        NUM_INSTRUCTIONS++;
        address.push_back(cur_addr);
        task.push_back(cur_task);
        src1.push_back("-1"); 
        src2.push_back("-1");
        dest.push_back("-1");
        stage.push_back(-1);

        if (cur_task == "ret") {
            break;
        }

        if (task.back() == "set" || task.back() == "ld" || task.back() == "st") {
            pipeline_in >> loc;
            dest.back() = loc;

            pipeline_in >> loc;
            src1.back() = loc;
        } else {
            pipeline_in >> loc;
            dest.back() = loc;

            pipeline_in >> loc;
            src1.back() = loc;

            pipeline_in >> loc;
            src2.back() = loc;
        }
    }
    run();
    return 0;
}